import numpy as np
import time

lista = list(range(1,10000000))
array_num = np.array([range(1, 1000)])

inicio = time.time()
soma_lista = sum(lista)
fim = time.time()

print('Tempo de execução da lista:', fim-inicio)
#print(lista)

inicio = time.time()
soma_array = sum(array_num)
fim = time.time()

print('Tempo de execução da Num:', fim-inicio)
#print(array_num)