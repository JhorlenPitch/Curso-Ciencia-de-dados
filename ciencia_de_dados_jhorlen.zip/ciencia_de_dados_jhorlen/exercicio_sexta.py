import numpy as np

array = np.random.randint(2, 15, 10)
print(array)

media = np.mean(array)
print(f'A média é igual á: {media}.')

primeiro = array[0]
print(f'O Primeiro elemento é o: {primeiro}.')

ultimo = array[-1]
print(f'O último elemento é o: {ultimo}.')

maior = np.max(array)
print(f'O maior valor é o: {maior}.')

menor = np.min(array)
print(f'O menor valor é o: {menor}.')

decrescente = np.sort(array)[::-1]
print(f'O array decrescente: {decrescente}.')

#Verificar quantas vezes um valor se repete
valores_unicos, contagens = np.unique(array, return_counts=True)
for valor, cont in zip(valores_unicos, contagens):
    print(f'Valor {valor} - Contagem {cont}')