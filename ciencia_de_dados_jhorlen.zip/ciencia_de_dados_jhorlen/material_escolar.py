lista_materiais = [] #Declarando a lista de materiais
lista_valor = [] #Declarando a lista de calores dos materiais

#Pegando os dados das listas e adicionando os valores
for material in range(2):
    item_material = str(input(f'Digite o nome do {material+1}º material:')) #Recebe um item da lista digitado
    lista_materiais.append(item_material) #Adicionando um item a lista de materiais
    valor_material = float(input(f'Digite o valor do {material+1}º material:')) #Recebe um valor da lista digitado
    lista_valor.append(valor_material)#Adicionando um valor a lista de materiais

#Mostrando a lista de materiais
print('\n!Lista de materiais!')
for material in range(2):
    print(f'{material+1}º -> Material: {lista_materiais[material]} - Valor R$ {lista_valor[material]}')

#Verificando o maior valor da lista de valores
maior = max(lista_valor)

#Exibindo pegando o indice no maior valor
indice_maior = lista_valor.index(maior)
#Pegando o nome do maior valor
nome_maior = lista_materiais[indice_maior]
#Exibindo o nome do maior valor
print(f'\nO maior valor da lista é nome {nome_maior} com um valor de R${maior}!\n')

#Descobrindo a soma dos valores da lista
soma = sum(lista_valor)
print(f'A soma dos valores é igual a R${soma}!\n')

#Vericando a quantidade de itens da lista
quantidade = len(lista_valor)

#Exibindo a quantidade de itens da lista
print(f'A quantidade de itens da lista é {quantidade}!\n')
media = soma / quantidade
#Exibindo o resultado da media da lista
print(f'A média da lista é igual a {media}!\n')

#Verificando se algum item da lista é igual a outro
for i in range(len(lista_valor)):
    for j in range(i+1, len(lista_valor)):
        if lista_valor[i] ==lista_valor[j]:
            print(f'Elemento na posição {i} ({lista_valor[i]}) é igual ao da posição {j} ({lista_valor[j]})')
        else:
            print('A lista não possui elementos iguais!')