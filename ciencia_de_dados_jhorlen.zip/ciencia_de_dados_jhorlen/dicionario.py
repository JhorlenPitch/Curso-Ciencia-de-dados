# Criando um dicionário com alguns dados
meu_dicionario = {}

# Criando um dicionário preenchido
dicionario_preenchido = {
    'nome':'Jhorlen',
    'idade': 24
}

#Exibindo o dicionário preenchido
print(dicionario_preenchido)

#Acessando um valor especifico com a chave
nome = dicionario_preenchido['nome']
print(nome)

#Acessando uma chave especifica que não existe
profissao = dicionario_preenchido.get('pro')
print(profissao)

#Acessando uma chave especifica que existe
idade = dicionario_preenchido.get('idade', 'Não encontrado!') #Retorna se for none
print(idade)

#Adicionar ou modificar elemento de um dicionario
dicionario_preenchido['sexo'] = 'masculino'

print(dicionario_preenchido)

#Atualizando um item no dicionario (pode criar assim tambem)
dicionario_preenchido.update({'idade':10})

print(dicionario_preenchido)

excluido = dicionario_preenchido.pop('idade')

print(excluido)

#Excluindo um item no dicionario
del dicionario_preenchido['sexo']

print(dicionario_preenchido)

#Pegando as chaves do dicionarios
todas_chaves = dicionario_preenchido.keys()

print(todas_chaves)

#Pegando todos os valores preenchidos
todos_valores = dicionario_preenchido.values()

print(todos_valores)

#Exibindo as chaves e valores em um for
for chave, valor in dicionario_preenchido.items():
    print(f'{chave} - {valor}')