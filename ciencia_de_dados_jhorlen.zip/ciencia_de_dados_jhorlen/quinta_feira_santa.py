produto = {
    'nome': 'Celular',
    'marca': 'Apple',
    'status': 'Novo',
    'origem': 'Madagascar',
    'categoria': 'Iphone'
}

#Mostrando todo o dicionário
print(produto)

#Adicionando a chave.
produto['valor_compra'] = 18.9

#Mostrando todo o dicionário
print(produto)

#Forçando o erro : Acessando uma chave especifica que não existe
chapolin = produto.get('chapolin', 'Não encontrado!') #Retorna se for none

#Mostrando o valor da chave
print(chapolin)

#Excluindo um item no dicionario
del produto['valor_compra']

#Mostrando todo o dicionário
print(produto)

#Pegando e Mostrando todas as chaves
todas_chaves = produto.keys()
print(todas_chaves)

#Pegando e Mostrando todos os valores
todos_valores = produto.values()
print(todos_valores)