import matplotlib.pyplot as plt

# Dados para o gráfico
x = [1, 2, 3, 4, 5]
y = [2, 3, 5, 7, 11]

# Criando o gráfico de linha
plt.plot(x, y, marker='o', linestyle='-', color='b', label='Linha Exemplo')

# Personalizando o gráfico
plt.title('Gráfico de Linha Exemplo')
plt.xlabel('Eixo X')
plt.ylabel('Eixo Y')
plt.legend()
plt.grid(True)

# Exibindo o gráfico
plt.show()